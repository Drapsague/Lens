import re
import os
import subprocess

from flask import Flask, request

app = Flask(__name__)


@app.route("/command1")
def com1():
    files = request.args.get("files", "")
    # Don't let files be `; rm -rf /`
    os.system("ls " + files)  # $result=BAD


@app.route("/command2")
def com2():
    files = request.args.get("files", "")
    # Don't let files be `; rm -rf /`
    subprocess.Popen("ls " + files, shell=True)  # $result=BAD


@app.route("/path-exists")
def path_exists():
    """
    os.path.exists is our sanitizer
    """
    path = request.args.get("path", "")
    if os.path.exists(path):
        os.system("ls " + path)  # $result=BAD
