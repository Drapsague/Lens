from flask import Flask, request

app = Flask(__name__)


@app.route("/code-ex")
def code_ex():
    code = request.args.get("code")
    exec(code)  # NOT OK
    eval(code)  # NOT OK
